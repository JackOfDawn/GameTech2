﻿using UnityEngine;
using System.Collections;

public class Movement : MonoBehaviour {

	public Vector2 direction;
	public float acceleration;
	
	// Update is called once per frame
	void Update () {
	
	}
}
